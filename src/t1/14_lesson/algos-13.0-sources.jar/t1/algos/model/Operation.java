package t1.algos.model;

import t1.algos.dto.Data;

public interface Operation<T> {
    T perform(Data<T> data);
}
