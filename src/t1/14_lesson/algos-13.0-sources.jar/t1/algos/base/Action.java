package t1.algos.base;

public interface Action {
    void invoke();
}
