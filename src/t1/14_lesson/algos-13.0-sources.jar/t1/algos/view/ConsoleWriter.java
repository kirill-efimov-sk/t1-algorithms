package t1.algos.view;

import t1.algos.viewmodel.CalculatorViewModel;
import t1.algos.dto.Data;

public class ConsoleWriter {
    private final CalculatorViewModel calculatorViewModel;

    public ConsoleWriter(CalculatorViewModel calculatorViewModel) {
        this.calculatorViewModel = calculatorViewModel;
        calculatorViewModel.subscribe("operation complete", this::write);
    }

    public void write() {
        Data d=calculatorViewModel.getCurData();
        System.out.println(d.getX()+d.operation()+d.getY()+"="+d.getRes());
    }
}
