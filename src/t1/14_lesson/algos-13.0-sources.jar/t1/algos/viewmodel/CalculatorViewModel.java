package t1.algos.viewmodel;

import t1.algos.base.Observer;
import t1.algos.dto.Data;
import t1.algos.model.Calculator;

public class CalculatorViewModel extends Observer {
    private Calculator calculator;
    private Data<Integer> data;

    public CalculatorViewModel(Calculator calculator) {
        this.calculator = calculator;
        calculator.subscribe("result", this::updateResult);
    }

    private void updateResult() {
        data.setRes(calculator.getResult());
        notify("operation complete");
    }

    public Data getCurData() {
        return data;
    }

    public void perform(Data<Integer> data) {
        this.data= new Data<>(data);
        calculator.makeOperation(data);
    }

}
